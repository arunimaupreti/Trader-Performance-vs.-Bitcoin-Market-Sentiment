Place the two source CSVs here before running the scripts/notebook:

- `fear_greed_index.csv`
- `historical_data.csv`

These are excluded from version control via `.gitignore` due to file size.
